# runner.py
from cpi_index_monitor.core.tracker import Tracker
from cpi_index_monitor.core.downloader import download
from cpi_index_monitor.sources.transparency_cpi import TransparencyCPI


def run_cpi():
    tracker = Tracker("cpi_history.json")
    known = tracker.load()

    source = TransparencyCPI()

    pdf = source.get_latest_pdf()

    if not pdf:
        print("No report found.")
        return

    if pdf in known:
        print("Already processed.")
        return

    print(f"New CPI report found: {pdf}")

    download(pdf)

    known.add(pdf)
    tracker.save(known)