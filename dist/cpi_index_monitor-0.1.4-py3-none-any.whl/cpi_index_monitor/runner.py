from cpi_index_monitor.core.tracker import Tracker
from cpi_index_monitor.core.downloader import download
from cpi_index_monitor.sources.transparency_cpi import TransparencyCPI


def run_cpi():
    tracker = Tracker("cpi_history.json")
    known = tracker.load()

    source = TransparencyCPI()

    file_url = source.get_latest_file()

    if not file_url:
        print("No report found.")
        return

    if file_url in known:
        print("Already processed.")
        return

    print(f"New CPI file found: {file_url}")

    download(file_url)

    known.add(file_url)
    tracker.save(known)